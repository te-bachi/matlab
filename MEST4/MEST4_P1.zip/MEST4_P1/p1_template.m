%% MEST - 4: Praktische Uebung 1 (Schwingungslehre)
%
% Modelle: Torsionsschwinger, Piezobalken, Pendel, Motormodell mit Feder
%
% 1. Maerz 2017
%
% Studenten: x, y
%
%% Versuch 1:


% Bemerkung
%% Versuch 2: 




% Bemerkung