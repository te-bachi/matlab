clc,clear close all

%A2 SEP 24.01.17