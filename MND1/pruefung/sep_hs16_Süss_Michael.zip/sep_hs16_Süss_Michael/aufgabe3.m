clc,clear close all

%A3 SEP 24.01.17