function [color] = orange()
    color = [ 255, 128, 0 ] / 255;
end

